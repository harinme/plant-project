# plant > 2024-06-05 3:11pm
https://universe.roboflow.com/test-qsudy/plant-vksot

Provided by a Roboflow user
License: CC BY 4.0

