# plant > 2024-06-14 7:47am
https://universe.roboflow.com/test-qsudy/plant-vksot

Provided by a Roboflow user
License: CC BY 4.0

