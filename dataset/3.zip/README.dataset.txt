# plant > 2024-06-10 12:04pm
https://universe.roboflow.com/test-qsudy/plant-vksot

Provided by a Roboflow user
License: CC BY 4.0

