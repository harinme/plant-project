# plant > 2024-06-10 3:40pm
https://universe.roboflow.com/test-qsudy/plant-vksot

Provided by a Roboflow user
License: CC BY 4.0

